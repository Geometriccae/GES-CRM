<?php

class test extends CI_Controller {
    public function index() {
        echo "hello kumara guru raj start working";
    }
    public function hello() {
        echo "hi hello";
    }
}

?>